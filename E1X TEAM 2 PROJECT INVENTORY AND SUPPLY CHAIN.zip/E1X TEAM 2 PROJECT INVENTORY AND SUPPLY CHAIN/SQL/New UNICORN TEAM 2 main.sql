-- Phase 2 — SQL: Querying the Database
-- SQL Questions
-- (1) Write SQL to calculate on-time delivery rate per supplier
-- (2) Use a CTE to identify products with more than 3 stockout weeks in the last year
-- (3) Use window functions to calculate rolling 4-week average stock level per product/store
-- (4)  Write a subquery-based query to find stores whose stockout rate is above the company average
-- ======================================================================================================
create database global_retail_unicorn_team_2;
use global_retail_unicorn_team_2;

-- tables were imported using the Table Data Import Wizard on the schemas
-- confirming table creation

show tables;
select* from dim_product;
select* from dim_store;
select* from dim_supplier;
select* from inventory_snapshots;
select* from purchase_orders;

-- Datatype: the datatype of each field were change and confirmed using the Alter Table on the Schemas
-- ========================================================================================================
-- -- (1) Write SQL to calculate on-time delivery rate per supplier
-- calculating on-time delivery rate per supplier.

SELECT 
    p.supplier_id,
    d.supplier_name,
    COUNT(*) as total_deliveries,

    SUM(case when p.actual_delivery_date <= p.expected_delivery_date then 1 else 0 end) as on_time_deliveries, -- checks for on time deliveries
        ROUND(SUM(case when p.actual_delivery_date <= p.expected_delivery_date then 1.0 else 0.0 end) / COUNT(*) * 100,2) 
        as on_time_delivery_rate -- calculates on time delivery rate.

from purchase_orders p

join dim_supplier d
    on p.supplier_id = d.supplier_id

group by 
    p.supplier_id,
    d.supplier_name

order by 
    p.supplier_id,
    d.supplier_name;
-- ===================================================================================================================
-- (2) Use a CTE to identify products with more than 3 stockout weeks in the last year
      -- identifying product with more than 3 stockout weeks using CTE 
      
with stockout as (select i.Product_id, d.product_name,
		count(distinct yearweek(snapshot_date)) as stockout_weeks
        
        from inventory_snapshots i
        join dim_product d on i.product_id = d.product_id
        
		where stock_on_hand = 0
        AND i.snapshot_date >= DATE_SUB(
            (SELECT MAX(snapshot_date) 
             FROM inventory_snapshots),
            INTERVAL 1 YEAR
          )
        group by product_id, product_name)
        SELECT *
FROM stockout
WHERE stockout_weeks > 3
ORDER BY 
    product_id,
    product_name;
        

-- ======================================================================================================================
-- (3) Use window functions to calculate rolling 4-week average stock level per product/store
-- rolling 4 weeks average per product

select i.product_id, i.snapshot_date, i.stock_on_hand,product_name,
						round(avg(stock_on_hand) over (partition by i.product_id order by snapshot_date
						rows between 3 preceding and current row),2) as rolling_4_weeks_avg_product
from inventory_snapshots i
join dim_product d on i.product_id = d.product_id
order by snapshot_date;


-- rolling 4 weeks average stock level per store
select i.store_id,i.snapshot_date,i.stock_on_hand,store_name,
					round(avg(stock_on_hand) over (partition by store_id order by snapshot_date
					rows between 3 preceding and current row),2) as rolling_4_weeks_avg_per_store
from inventory_snapshots i
join dim_store ds on i.store_id = ds.store_id
order by snapshot_date;

-- ===========================================================================================================================
-- (4)  Write a subquery-based query to find stores whose stockout rate is above the company average
with stockout_per_store as (select i.store_id, store_name, count(*) as total_stock,

			sum(case when stock_on_hand = 0 then 1 else 0 end) as stockout_record, -- checks stores where stock_on_hand is 0
            
			round(sum(case when stock_on_hand = 0 then 1 else 0 end) /count(*) *100,2) as stockout_rate -- calculates the stockout rate for each stores. 
            from inventory_snapshots i
            
            join dim_store ds on i.store_id = ds.store_id -- joining the dim_store table and the inventory_snapshot table
            group by store_id
            )
            -- subquery that checks for stores whose stockout rate is above the companies average
SELECT store_id,store_name,stockout_rate
			from stockout_per_store -- table name in the outer query and contains information like stockout rate forr each store, stockout_record,and total_stock
			where stockout_rate > (select avg(stockout_rate)  
			from stockout_per_store) 
             
            group by store_id, stockout_rate
            order by stockout_rate desc;
            
-- from anslysis 4 stores were seen to have the stockout rate above the companies average 
-- with Global Retail Orchard having the Highest stockout rate of 5.83%
-- & Global Retail Oxford Street having about 5%
-- Global Retail Makati 4.86%
-- Global Retail Alexanderplatz havin the least stockout rate of about 4.31%